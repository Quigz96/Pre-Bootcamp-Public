const Product = require('../models/product.model')



const addProduct = (req, res) => {
    Product.create(req.body)
    .then((result)=> {
        res.json(result)
    }).catch((err) => {
        console.log(err)
    })
}

const getAllProduct = (req,res) =>{
    Product.create(req.body)
    .then((result)=> {
        res.json(result)
    }).catch((err) => {
        console.log(err)
    })
}


module.exports = {
    addProduct,
    getAllProduct
}
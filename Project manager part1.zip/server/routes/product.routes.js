const ProductController = require('../controllers/product.controller')



module.exports = (app) => {
    app.get('/api/getAllProduct', ProductController.getAllProduct)
    app.post('api/addProduct', ProductController.addProduct)
}
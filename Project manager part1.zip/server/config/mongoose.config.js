const mongoose = require('mongoose')

mongoose.connect('mongodb://localhost/mytestdb', () =>{
    console.log('Connected to MongoDB!')
})
const ProductController = require('../controllers/product.controller')



module.exports = (app) => {
    app.get('/api/getAllProducts',ProductController.getAllProducts)
    app.post('/api/addProduct',ProductController.addProduct)
    app.get('/api/getOneProduct/:id',ProductController.getOneProduct)
    app.put('/api/updateProduct/:id',ProductController.updateProduct)
    app.delete('/api/deleteProduct/:id',ProductController.deleteProduct)
}
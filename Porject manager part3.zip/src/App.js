import './App.css';
import Form from './components/Form'
import ProductList from './components/ProductList';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import OneProduct from './components/OneProduct';
import UpdateProduct from './components/UpdateProduct';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path='/form' element={<Form />}/>
        <Route path='/' element={<ProductList />}/>
        <Route exact path='/product/:id' element={<OneProduct/>}/>
        <Route exact path='/UpdateProduct/:id' element={<UpdateProduct/>}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;

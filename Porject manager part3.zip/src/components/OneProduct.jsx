import React, {useState, useEffect} from 'react';
import {useNavigate, useParams} from "react-router-dom";
import axios from "axios";
import {Link} from "react-router-dom";


const OneProduct = () => {

const {id} = useParams();
const navigate = useNavigate();

const [oneProduct, setOneProduct] = useState({})

useEffect(() => {
    console.log(id)
    axios.get(`http://localhost:8000/api/getOneProduct/${id}`)
    .then((res) => {
        console.log(res.data)
        setOneProduct(res.data)
    }).catch((err) => {
        console.log(err)
    })
}, [])

const deleteHandler = () => {
    axios.delete(`http://localhost:8000/api/deleteProduct/${id}`)
    .then((res) => {
        console.log(res)
        console.log(res.data);

        navigate("/");
    })
    .catch((err) => {
        console.log(err);
    });
};



return (
    <div>
    <h1>{oneProduct.title}</h1>
    <h2> Price: ${oneProduct.price}</h2>
    <h3>Description: {oneProduct.description}</h3>
    <Link to={`/updateProduct/${oneProduct._id}`}>Edit Product</Link>
    <Link onClick={deleteHandler}>Delete</Link>
    </div>
)
}

export default OneProduct

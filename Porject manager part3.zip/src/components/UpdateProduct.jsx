import React, {useState, useEffect} from "react";
import {useNavigate, useParams} from "react-router-dom";
import axios from "axios";


const UpdateProduct = () => {
    const {id} = useParams();
    const [title,setTitle] = useState('')
    const [price,setPrice] = useState('')
    const [description,setDescription] = useState('')

    const navigate = useNavigate();


    const [headerTitle, setHeaderTitle] = useState("");

    useEffect(() => {
        axios
        .get(`http://localhost:8000/api/getOneProduct/${id}`)
        .then((res) =>{
            console.log(res.data);
            setTitle(res.data.title)
            setPrice(res.data.price)
            setDescription(res.data.description);
        })
        .catch((err) => console.log(err))
    }, []);

    const submitHandler = (e) => {
        e.preventDefault();

        axios.put(`http://localhost:8000/api/updateProduct/${id}`, 
        {title, 
        price, 
        description,}
        )
        .then((res) => {
            console.log(res);
            console.log(res.data)
            navigate("/")
        })

        .catch((err) => {
            console.log(err);
        });
    };

    console.log({title})
    console.log({description})
    return (
        <div>
            <header>Edit product</header>
            <form onSubmit={submitHandler}>
            <label>Title</label>
            <input type="text" onChange={(e) => setTitle(e.target.value)} value={title}/>
            <label>Price</label>
            <input type="number" onChange={(e) => setPrice(e.target.value)} value={price}/>
            <label>Description</label>
            <input type="text" onChange={(e) => setDescription(e.target.value)} value={description}/>
            <button type="submit">Update</button>
        </form>
        </div>
    )

}

export default UpdateProduct

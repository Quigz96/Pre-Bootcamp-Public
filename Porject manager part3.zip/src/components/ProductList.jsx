import React, {useEffect, useState} from 'react'
import axios from 'axios'
import {Link} from "react-router-dom";
import Form from './Form';


const ProductList = () => {

    const [list,setList] = useState([])

    useEffect(() => {
        axios.get('http://localhost:8000/api/getAllProducts')
        .then((res) => {
            console.log(res.data)
            setList(res.data)
        }).catch((err) => {
            console.log(err)
        })
    }, [])

    return (
        <><Form />
        <div>
        <h1>All Products:</h1>
            {
                list.map((products)=>(
                    <div>
                        <Link to ={`/product/${products._id}`}>
                        <h2>{products.title}</h2>
                        </Link>
                    </div>
                ))
            }
        </div>
        </>
    )
}

export default ProductList

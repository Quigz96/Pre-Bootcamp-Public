from flask_app import app
from flask import render_template, redirect, session, request, flash
from flask_bcrypt import Bcrypt 
from flask_app.models.users import User
bcrypt = Bcrypt(app)

@app.route('/')
def index():
    if 'user_id' not in session:
        return render_template('index.html')
    else:
        return redirect('/dashboard')

@app.route('/register', methods=['POST'])
def register():
        isValid = User.validate_register(request.form)
        if not isValid:
            return redirect('/')
        newUser = {
            "user_name": request.form['user_name'],
            "password": bcrypt.generate_password_hash(request.form['password'])
        }
        id = User.save(newUser)
        if not id:
            flash('Something went wrong')
            return redirect('/')
        else:
            session['user_id'] = id
            flash("you are now logged in")
            return redirect('/dashboard')

@app.route('/login', methods=['POST'])
def login():
    data = {
        'user_name': request.form['user_name']
    }
    user = User.get_by_user_name(data)
    if not user:
        flash("Invalid username!", "login")
        return redirect('/')
    if not bcrypt.check_password_hash(user.password, request.form['password']):
        flash("Invalid Password", "login")
        return redirect('/')
    else:
        session['user_id'] = user.id
        return redirect('/dashboard')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')
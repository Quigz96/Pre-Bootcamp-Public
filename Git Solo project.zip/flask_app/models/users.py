from flask_app.config.mysqlconnection import connectToMySQL
import re 
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
from flask import flash



class User: 
    def __init__(self, data):
        self.id = data['id']
        self.user_name = ['user_name']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
    db = "sports"

    @classmethod
    def save(cls, data):
        query = "INSERT INTO users (user_name,password) VALUES(%(user_name)s, %(password)s)"
        return connectToMySQL(cls.db).query_db(query,data)
    
    @classmethod
    def update(cls, data):
        query = 'UPDATE user SET userName=%(userName)s, WHERE id = %(id)s;'
        return connectToMySQL(cls.db).query_db(query,data)

    @classmethod
    def delete(cls, data):
        query = 'DELETE FROM user WHERE id = %(id)s;'
        return connectToMySQL(cls.db).query_db(query,data)
    
    @classmethod
    def get_all(cls):
        query = "SELECT * FROM user;"
        results = connectToMySQL(cls.db).query_db(query)
        users = []
        for row in results:
            users.append(cls(row))
        return users

    @classmethod
    def get_by_user_name(cls,data):
        query = "SELECT * FROM user WHERE user_name = %(user_name)s;"
        results = connectToMySQL(cls.db).query_db(query,data)
        if len(results) < 1:
            return False
        return cls(results[0])

    @classmethod
    def get_by_id(cls,data):
        query = "SELECT * FROM user WHERE id = %(id)s;"
        results = connectToMySQL(cls.db).query_db(query,data)
        return cls(results[0])

    @staticmethod
    def validate_register(user):
        isvalid = True
        query = "SELECT * FROM user WHERE username = %(username)s;"
        results = connectToMySQL(User.db).query_db(query,user)
        if len(results) >= 1:
            flash("Username is already taken!", "register")
            isvalid= False
        if len(user['password']) < 8:
            flash("Password must be at least 8 characters","register")
            isvalid= False
        if user['password'] != user['confirm']:
            flash("Password don't match", "register")
        return isvalid